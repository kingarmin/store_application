import stuffs as st
x=st.stuff(5,2,3,4,5,6)
y=st.stuff()
print(y.price , x.price)