from ast import For
from distutils.log import debug
from re import search
import sort
import filter as F
from logging import exception
import os
import stuffs as st
from time import sleep
from colorama import Fore, Style, init
exit_situation=False
init()
item=0
stuffs=['empty']
def exit(mode='normall'):
    global exit_situation
    if mode=='normall':
        clear()
        exit_situation=input("Are you sure?(Y o N)")
        exit_situation=exit_situation.upper()
        if exit_situation=='Y':
            exit_situation=True
        elif exit_situation=='N':
            start_menu(0)
            exit_situation=False
            global item
            item=0
        else:
            print("EROR!!")


def clear():
    if os.name=='nt':
        os.system("cls")
    else:
        os.system("clear")



def start_menu(item):
    clear()
    if item==0 : 
        print('* '*9)
        print("* exit          *")
        print('* '*9)
        print(" customer menu")
        print()
        print(" manager menu")
    elif item==1:
        print(" exit ")
        print('* '*9)
        print("* customer menu *")
        print('* '*9)
        print(" manager menu")
    else:
        print(" exit ")
        print()
        print(" customer menu")
        print('* '*9)
        print("* manager menu  *")
        print('* '*9)



def welcom():                               #show logo
    os.system("CLS")
    print(Fore.RED,end='')
    print("* " *11)
    sleep(0.2)
    print(Fore.BLUE,end='')
    print("*",end='')
    print(" "*19,end='')
    print("*")
    sleep(0.2)
    print(Fore.GREEN,end='')
    print("*    king armin     *")
    sleep(0.2)
    print(Fore.YELLOW,end='')
    print("*",end='')
    print(" "*19,end='')
    print("*")
    sleep(0.2)
    print(Fore.RED,end='')
    print("* " *11)
    sleep(1)
    clear()
    print(Style.RESET_ALL)

def Determiner(item):
    if item==2:
        manager_menu()
        
def manager_menu(last_submenu='empty'):
    clear()
    print(Fore.RED+"_________________________________________"+Style.RESET_ALL)
    print("0-exit")
    print("1-add commodity")
    print("2-delet commodity")
    print("3-reset commodity list!!!!!!!!!")
    print("4-show commodity list ")
    print("5-back")
    print(Fore.RED+"_________________________________________"+Style.RESET_ALL)
    submenu=last_submenu
    if submenu=='0':
        if last_submenu=='0':
            exit()
    elif last_submenu=='5':
            start_menu(0)
            global item
            item=0
    elif last_submenu=='1':
        global stuffs
        try:
            x=st.stuff(int(input("price: ")),int(input("size: ")),input("color: "),input("brand: "),input("name: "))
            debuger=0
            an=0
            for j,i in enumerate(stuffs):
                if i=='empty' and debuger==0:
                    debuger=1
                    an=j
            if debuger==0:
                x.stv('id',id=len(stuffs)+1)
                stuffs.append(x)
            else:
                x.stv('id',id=an+1)
                stuffs[an]=x
            if input("if you want add another object enter 1: ")=='1':
                manager_menu('1')
            else:
                manager_menu()
        except Exception as e:
            print(str(e))
            sleep(2)
            manager_menu('1')
    elif last_submenu=='3':
        stuffs=[]
    elif last_submenu=='4':
        F.filter_getin()
        if F.filter_mode=='id':#any filter
            sort.sort_st(input=stuffs)
            input("press enter to continu") 
        else:#filter
            search=stuffs.copy()
            for i in (stuffs):
                if F.filtering(i,F.filter_mode):
                    search.remove(i)
            #filtering finish 
            sort.sort_st(sort_mode=sort.get_sort_mode(),input=search)
            input("press enter to continu") 
        manager_menu()
    elif last_submenu=='2':
        F.filter_getin('2')
        for andis,i in enumerate(stuffs):
            if F.filtering(i,F.filter_mode):
                stuffs[andis]='empty'
    else:
        try:
            submenu = (input("please choose one of the options:"))
            while not(int(submenu)>=0 and int(submenu)<=5):
                print("EROR: your entry is incorrect , please try again ")
                submenu = (input("please choose one of the options:"))
            manager_menu(submenu)
        except Exception as e:
            print(str(e))
            sleep(3)
            manager_menu()



