
from stuffs import stuff,print_object
from colorama import Fore, Style, init
init()

def get_sort_mode():
    print(Fore.RED+"_________________________________________"+Style.RESET_ALL)
    print("1-sort by size")
    print("2-sort by price")
    print('any key:id')
    x=input("chose your sort mode: ")
    if x=='1':
        x=input("chose your sort mode(1-from high to low 2-from low to high): ")
        if x=='1':
            return 'size_sort'
        else:
            return 'size_lth_sort'
    elif x=='2':
        x=input("chose your sort mode(1-from high to low 2-from low to high): ")
        if x=='1':
            return 'price_sort'
        else:
            return 'price_lth_sort'
    else:
        return 'id'

def sort_st(sort_mode='id',input=stuff()):
    if sort_mode=='id':
        for i in input:
            if i!='empty':
                print_object(i)
    elif sort_mode=='size_sort':
        size=[]
        for i in input:
            if i!='empty':
                size.append(i.size)
        size.sort(reverse=True)
        for i in size:
            for j in input:
                if i==j.size:
                    print_object(j)
    elif sort_mode=='size_lth_sort':
        size=[]
        for i in input:
            if i!='empty':
                size.append(i.size)
        size.sort()
        for i in size:
            for j in input:
                if i==j.size:
                    print_object(j)
    elif sort_mode=='price_sort':
        price=[]
        for i in input:
            if i!='empty':
                price.append(i.price)
        price.sort(reverse=True)
        for i in price:
            for j in input:
                if i==j.price:
                    print_object(j)
    else:
        price=[]
        for i in input:
            if i!='empty':
                price.append(i.price)
        price.sort()
        for i in price:
            for j in input:
                if i==j.price:
                    print_object(j)