from colorama import Fore, Style, init
init()
class stuff:
    def __init__(self,price=0,size=0,color=0,brand=0,name="",id=0):
        self.price = price
        self.size = size
        self. color = color
        self.brand = brand
        self.name=name
        self.id=id
    def stv(self,property,price=0,size=0,color=0,brand=0,id=0):
        if property=='price':
            self.price=price
        elif property=='size':
            self.size=size
        elif property=='color':
            self.color=color
        elif property=='brand':
            self.brand=brand
        elif property=='id':
            self.id=id
    def bio(self,mode='all'):
        if mode=='all':
            out=[self.name , self.price , self.size , self.brand , self.color,self.id]
        elif mode=='brand':
            out=[self.brand]
        elif mode=='price':
            out=[self.price]
        elif mode=='color':
            out=[self.color]
        elif mode=='size':
            out=[self.size]
        elif mode=='id':
            out=[self.id]
        else:
            out=[self.name]
        return out

def print_object(x=stuff()):
    print('name: ',x.bio('name') )
    print('brand : ',x.bio('brand'))
    print('size: ',x.bio('size') )
    print('price: ',x.bio('price') )
    print('color: ',x.bio('color') )
    print(Fore.RED+'id:  ',x.bio('id') )
    print(Fore.BLUE+"_________________________________________"+Style.RESET_ALL)

