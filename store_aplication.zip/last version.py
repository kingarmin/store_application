import keyboard
import display as dp 
from display import item 


dp.welcom()
dp.start_menu(item)
while 1:
    if keyboard.is_pressed("down"):
        if item<2:
            item +=1
        else:
            item = 0
        dp.start_menu(item)
        #print (item)
    elif keyboard.is_pressed("up"):
        if item>0:
            item -=1
        else:
            item=2 
        dp.start_menu(item)
        #print (item)
    elif keyboard.is_pressed("enter"):
        input()
        if item==0:
            dp.exit()
            if dp.exit_situation ==True:
                dp.welcom()
                dp.sleep(0.5)
                print("thanack for your choice ")
                dp.sleep(2)
                dp.clear()
                break
            else:
               dp.start_menu(0)
        else:
            dp.Determiner(item)
    if dp.exit_situation ==True:
        dp.welcom()
        dp.sleep(0.5)
        print("thanack for your choice ")
        dp.sleep(2)
        dp.clear()
        break
#    elif exit_situation=="back to home menue":
#        item = 0
#        start_menu(item)
#        exit_situation=False
    dp.sleep(0.05)