from ast import Return
from time import sleep
from warnings import filters
import display as dp
from colorama import Fore, Style, init
import stuffs as st
filter_mode=[]#0:brand,1:color
filter_size=[]
filter_price=[]
init()

def filter_getin(filter_selection='empty'):
    global filter_mode
    global filter_size
    global filter_price
    dp.clear()
    print(Fore.RED+"_________________________________________"+Style.RESET_ALL)
    print('1-search all')
    print('2-search with filter')
    print(Fore.RED+"_________________________________________"+Style.RESET_ALL)
    filter_mode=[0,0,0]
    filter_price=[0,0]
    filter_size=[0,0]
    if filter_selection=='empty':
        filter_selection = input("mode: ")
        filter_getin(filter_selection)
    elif  filter_selection=='1':
        filter_mode='id'
    elif filter_selection=='2':
        print('0-back')
        print('1-brand')
        print('2-color')
        print('3-id')
        print('4-size')
        print('5-price')
        print('enter 000 to watch your search output ')
        x=input("mode: ")
        while x!='000':
            if x=='0':
                filter_getin('2')
            elif x=='1':
                filter_mode[0]=input("brand: ")
            elif x=='2':
                filter_mode[1]=input("color: ")
            elif x=='3':
                filter_mode[2]=int(input("id: "))+1
            elif x=='4':
                filter_size = input('size (min max):').split()
                filter_size=list(map(int,filter_size))
            elif x=='5':
                filter_price=input('price (min max): ').split()
                filter_price=list(map(int,filter_price))
            x=input("mode: ")
    elif len(filter_mode)==0:
        filter_getin()

def filtering(input=st.stuff(),filters=[]):
    debuger=0
    info=input.bio()# out=[self.name , self.price , self.size , self.brand , self.color]
    if (info[3]==filters[0]) or filters[0]==0: #brand
        debuger+=1
    if (info[4]==filters[1]) or filters[1]==0:
        debuger+=1
    if (info[5]==(filters[2]+1)) or filters[2]==0:
        debuger+=1
    if(info[2]>=filter_size[0] and info[2]<=filter_size[1]) or (filter_size[0]==0 and filter_size[1]==0):
        debuger+=1
    if(info[2]>=filter_price[0] and info[2]<=filter_price[1]) or (filter_price[0]==0 and filter_price[1]==0):
        debuger+=1
    if debuger==5:
        return False
    return True
