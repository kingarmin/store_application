from ast import For
import os
from pickle import TRUE
import time
import keyboard
from colorama import Fore, Style, init
init()
exit_situation=False
stuffs=[]
def list_to_int(x):
    out=[]
    for i in x:
        out.append(int(i))
    return out


#class : 
class stuff:
    def __init__(self,price=0,size=0,color=0,brand=0,name=""):
        self.price = price
        self.size = size
        self. color = color
        self.brand = brand
        self.name=name
    def stv(self,property,price=0,size=0,color=0,brand=0):
        if property=='price':
            self.price=price
        elif property=='size':
            self.size=size
        elif property=='color':
            self.color=color
        elif property=='brand':
            self.brand=brand
    def bio(self,mode='all'):
        if mode=='all':
            out=[self.name , self.price , self.size , self.brand , self.color]
        elif mode=='brand':
            out=[self.brand]
        elif mode=='price':
            out=[self.price]
        elif mode=='color':
            out=[self.color]
        elif mode=='size':
            out=[self.size]
        else:
            out=[self.name]
        return out
    
        
#display_functions:


def printer(start_char=" ",start=0 , end_culum=1 ,char='*' , color=7 , delay=0):
    for i in range(start):
        print(start_char,end='')
    os.system("color "+str(color))
    for i in range (end_culum):
        print(char,end=" ")
    time.sleep(delay)
    

def welcom():                               #show logo
    os.system("CLS")
    printer(end_culum=11 , color=2 , delay=1)
    print()
    printer(start_char='*' , start=1 , end_culum=9 , char=" " , color=3 , delay=1)
    print(" *")
    print("*    king armin     *")
    printer(start_char='*' , start=1 , end_culum=9 , char=" " , color=4 , delay=1)
    print(" *")
    printer(end_culum=11 , color='b' , delay=1)
    print()
    time.sleep(1)
    os.system("CLS")
    os.system("color 7")

def start_menu(Item=0) :    #exit customer manager
    os.system("CLS")
    if(Item==0):
        printer(end_culum=10 )
        print()
        for i in range(3):
            printer(start_char="*",start=1,end_culum=8 , char=" ")
            print(" *")
        print("* 0-Exit          *")
        for i in range(3):
            printer(start_char="*",start=1,end_culum=8 , char=" ")
            print(" *")
        printer(end_culum=10 )
        print()
        for i in range(4):
            print()
        print(" 1-customers")
        for i in range(8):
            print("")
        print(" 2-manager")
        for i in range(4):
            print()
    elif(Item==1):
        for i in range(4):
            print()
        print(" 0-Exit")
        for i in range(4):
            print()
        printer(end_culum=10 )
        print()
        for i in range(3):
            printer(start_char="*",start=1,end_culum=8 , char=" ")
            print(" *")
        print("* 1-customers     *")
        for i in range(3):
            printer(start_char="*",start=1,end_culum=8 , char=" ")
            print(" *")
        printer(end_culum=10 )
        print()
        for i in range(4):
            print("")
        print(" 2-manager")
        for i in range(4):
            print()
    else:
        for i in range(4):
            print()
        print(" 0-Exit")
        for i in range(4):
            print()
        for i in range(4):
            print()
        print(" 1-customers")
        for i in range(4):
            print()
        printer(end_culum=10 )
        print()
        for i in range(3):
            printer(start_char="*",start=1,end_culum=8 , char=" ")
            print(" *")
        print("* 2-manager       *")
        for i in range(3):
            printer(start_char="*",start=1,end_culum=8 , char=" ")
            print(" *")
        printer(end_culum=10 )
        print()

def customer_menu():
        printer(end_culum=10,char="#")
        print()
        print("* custumers menue *")
        printer(end_culum=10,char="#")
        print()
        print()
        printer(end_culum=7,char="#")
        print()
        print("# 0-Exit    #")
        print("# 1-Back    #") 
        printer(end_culum=7,char="#") 
        print()
        print() 
        print(Fore.RED+"upgradin..."+Style.RESET_ALL)

def print_object(x=stuff()):
    print('name: ',x.bio('name') )
    print('brand : ',x.bio('brand'))
    print('size: ',x.bio('size') )
    print('price: ',x.bio('price') )
    print('color: ',x.bio('color') )

def manager_menu(last_submenu="empty"):
    os.system("CLS")
    print("________________________________________________________________")
    print("0-exit")
    print("1-add commodity")
    print("2-delet commodity")
    print("3-reset commodity list!!!!!!!!!")
    print("4-show commodity list ")
    print("5-back")
    print("________________________________________________________________")
    submenu=last_submenu
    if submenu=='0':
        exit("manager_menu")
    elif submenu=='5':
        Determiner("start")
    elif submenu=='1':
        global stuffs
        iput_stuff=stuff(name=input("enter name: "),price=float(input("enter peice: ")),brand=(input("enter brand: ")),size=int(input("enter size: ")),color=(input("enter color: ")))
        stuffs.append(iput_stuff)
        print("thank:))")
    elif submenu=='3':
        reset=input("are you sure?(Y or N")
        if(reset=='Y'):
            stuffs=[]
    elif submenu=='4':
        filter=input("If you want to add filter,click 1 . If you don't want ,pressn enter button: ")
        if filter!='1':
            for i in stuffs:
                print_object(i)
                print(Fore.RED+"_________________________________________________"+Style.RESET_ALL)
        else:
            filter=[]# [0]=brand
            filter.append(input("brand (if you dont want to have this filter , type empty_filter) : "))
            filter.append(input("color (if you dont want to have this filter , type empty_filter) : "))
            size_avg = input("size (if you dont want to have this filter , type empty_filter)  (min max) : ")
            price_avg=input("price (if you dont want to have this filter , type empty_filter)  (min max) : ")
            
            search=stuffs
            for i in search:
                brand=i.bio('brand')
                color=i.bio('color')
                size=i.bio('size')
                price=i.bio('price')
                if filter[0]!='empty_filter' and filter[0]!=brand[0]:
                    search.remove(i)
                if filter[1]!='empty_filter' and filter[1]!=color[0]:
                    search.remove(i)
                if size_avg!='empty_filter':
                    size_avg=size_avg.split()
                    size_avg=list_to_int(size_avg)
                    if not(size[0]>=size_avg[0] and size[0]<=size_avg[1]):
                        search.remove(i)
                if price_avg!='empty_filter':
                    price_avg=price_avg.split()
                    price_avg=list_to_int(price_avg)
                    if not(price[0]>=price_avg[0] and price[0]<=price_avg[1]):
                        search.remove(i)
            for i in search:
                print_object(i)
                print(Fore.RED+"_________________________________________________"+Style.RESET_ALL)
        input("press enter to continue")
    else:
        submenu = (input("please choose one of the options:"))
        while not(int(submenu)>=0 and int(submenu)<=5):
            print("EROR: your entry is incorrect , please try again ")
            submenu = (input("please choose one of the options:"))
        manager_menu(submenu)


#menu selection:

def Determiner(Item):
    os.system("CLS")
    if Item==1:#custommer
        customer_menu()
        exit("customer_menu")
    elif Item==2:
        manager_menu()
    else:
        global item
        item=0
        start_menu(item)


#exit menue :

def exit(mode="normal"):
   global exit_situation
   if(mode=="normal"):
        os.system("CLS")
        exit_situation=input("Are you sure?(Y o N)")
        if( exit_situation=="Y" or exit_situation=="y"):
            print("Thank you for your choice")
            time.sleep(2)
            os.system("CLS")
            exit_situation=True
        elif(exit_situation=="N" or exit_situation=="n"):
            exit_situation=0;
            start_menu(exit_situation)
        else:
            print("index EROR!!!!!!!!!!!!!!!!!!!")
            time.sleep(1)
            exit_situation=0
            start_menu(exit_situation)
   elif(mode=="customer_menu"):
        exit_situation=int(input("Enter one of the options: "))
        if exit_situation==0:
            exit("normal")
        elif exit_situation==1:
            exit_situation="back to home menue"
        else:
            print("index EROR!!!!!!!!!!!!!!!!!!!")
            time.sleep(1)
            exit_situation=0
            start_menu(exit_situation)
   elif mode=="manager_menu" :
        exit("normal")

            
#code:






welcom()
item=0
start_menu(item)
while 1:
    if keyboard.is_pressed("down"):
        if item<2:
            item +=1
        else:
            item = 0
        start_menu(item)
        #print (item)
    elif keyboard.is_pressed("up"):
        if item>0:
            item -=1
        else:
            item=2 
        start_menu(item)
        #print (item)
    elif keyboard.is_pressed("enter"):
        input()
        if item==0:
            exit()
            if(exit_situation==True):
                break
            else:
                start_menu(exit_situation)
        else:
            Determiner(item)
    if exit_situation==True:
        break
    elif exit_situation=="back to home menue":
        item = 0
        start_menu(item)
        exit_situation=False
    time.sleep(0.05)

